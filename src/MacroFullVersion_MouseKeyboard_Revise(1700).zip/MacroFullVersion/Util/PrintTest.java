package MacroFullVersion.Util;

public class PrintTest {
	
	public static void PrintSystemOrder(String str)
	{
		System.out.println("[RobotClassValue] - " + str);
	}
	
	public static void PrintUserOrder(String str)
	{
		System.out.println("[UserOrder] - " + str);
	}
}

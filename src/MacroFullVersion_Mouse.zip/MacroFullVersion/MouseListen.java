package MacroFullVersion;

import java.awt.MouseInfo;
import java.awt.Point;
import java.util.ArrayList;

import org.jnativehook.mouse.NativeMouseEvent;
import org.jnativehook.mouse.NativeMouseInputListener;

public class MouseListen implements NativeMouseInputListener{

	private ArrayList<EventHandle> arrayList;
	
	public MouseListen(ArrayList<EventHandle> arrayList)
	{
		this.arrayList = arrayList;
	}
//
	@Override
	public void nativeMouseClicked(NativeMouseEvent e) {
		// TODO Auto-generated method stub
					
		synchronized(arrayList)
		{
			arrayList.add(new EventHandle(new String("MouseClicked"),e.getPoint()));
			System.out.println("MouseClicked!!!!");
		}
		//System.out.println(e.getX()+"," +e.getY());
	}

	@Override
	public void nativeMousePressed(NativeMouseEvent e) {
		// TODO Auto-generated method stub		
	}

	@Override
	public void nativeMouseReleased(NativeMouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void nativeMouseMoved(NativeMouseEvent e) {
		// TODO Auto-generated method stub

//		try {
//			arrayList.add(new EventHandle(new String("MouseMoved"),e.getPoint()));
//			System.out.println("MouseMoved(Add) : " + e.getPoint().getX() + "," + e.getPoint().getY());
//		} catch (InterruptedException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		
	}

	@Override
	public void nativeMouseDragged(NativeMouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
	
}

package MacroFullVersion;

import java.awt.AWTException;
import java.awt.Point;
import java.awt.PointerInfo;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class ScreenControl implements Initializable{

	@FXML private Button btnStart;
	@FXML private Button btnPlay;
	@FXML private Button btnStop;
	@FXML private TextField txtStr;
	
	private ArrayList<EventHandle> arrayList;
	private boolean status = false;
	private KeyboardListen k_listen;
	private MouseListen m_listen;
	private MouseMoveListen m_th;
	
	private Robot robot; 
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		btnStart.setOnAction(event->ActionStart());
		btnStop.setOnAction(event->ActionStop());
		btnPlay.setOnAction(event->ActionPlay());
		
		btnStart.setDisable(false);btnStop.setDisable(true);  btnPlay.setDisable(true);
		arrayList = new ArrayList<EventHandle>();

		}
	
	public void ActionStart()
	{		
		btnStart.setDisable(true);btnStop.setDisable(false);  btnPlay.setDisable(true);

		if(!arrayList.isEmpty())
		{
			arrayList.clear();
			arrayList = new ArrayList<EventHandle>();
		}
				
		m_th = new MouseMoveListen(arrayList);
		
		status = true;
		System.out.println("Press Start.");
		
		
		try {
			GlobalScreen.registerNativeHook();
			
		} catch (NativeHookException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		k_listen = new KeyboardListen(arrayList);
		m_listen = new MouseListen(arrayList);
		m_th.start();
		GlobalScreen.addNativeKeyListener(k_listen);
		GlobalScreen.addNativeMouseListener(m_listen);
		GlobalScreen.addNativeMouseMotionListener(m_listen);
		
		
	}
	
	public void ActionStop() 
	{
		btnStart.setDisable(false);btnStop.setDisable(true);  btnPlay.setDisable(false);

		System.out.println("Stop");
		
		
		// Global Key Listener( Keyboard, Mouse ) ����		
		GlobalScreen.removeNativeKeyListener(k_listen);
		GlobalScreen.removeNativeMouseListener(m_listen);
		GlobalScreen.removeNativeMouseMotionListener(m_listen);
		try {
			GlobalScreen.unregisterNativeHook();
		} catch (NativeHookException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		// MouseMoveListen Class ����. (Interrup()�� �߻���Ű�� �ش� Ŭ������ sleep()����ó���� �߻��� )
		m_th.interrupt();
		
	}
	
	public void ActionPlay()
	{
		btnStart.setDisable(false);btnStop.setDisable(false);  btnPlay.setDisable(false);

		synchronized(arrayList)
		{
			try {
				robot = new Robot();
				
				for(EventHandle i : arrayList)
				{
					if( i.getEventName().equals("MouseClicked") )
					{						
						Point pos = i.getPosition();				
						robot.mouseMove((int) pos.getX(), (int) pos.getY());
						robot.mousePress(InputEvent.BUTTON1_MASK);
						robot.mouseRelease(InputEvent.BUTTON1_MASK);	
						System.out.println("MouseClicked :");
					}
					else if ( i.getEventName().equals("MouseMoved"))
					{
						Point pos = i.getPosition();	
						
						System.out.println("MouseMoved :"+ pos.x + "," + pos.y);									
						robot.mouseMove((int) pos.getX(), (int) pos.getY());						
					}
					
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				System.out.println("Play.");
				
			} catch (AWTException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	

}


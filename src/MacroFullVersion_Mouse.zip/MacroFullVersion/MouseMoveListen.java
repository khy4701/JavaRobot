package MacroFullVersion;

import java.awt.MouseInfo;
import java.awt.Point;
import java.util.ArrayList;

public class MouseMoveListen extends Thread{

	private ArrayList<EventHandle> arrayList;
	
	public MouseMoveListen(ArrayList<EventHandle> arrayList)
	{
		this.arrayList = arrayList;
	}
	
	public void run()
	{
		while (true) {
			synchronized (arrayList) {

				Point pos = MouseInfo.getPointerInfo().getLocation();
				arrayList.add(new EventHandle(new String("MouseMoved"), pos));

				System.out.println("MousePos Added : " + pos.x + "," + pos.y);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block					
					break;
				}
			}
		}
		
	}
}

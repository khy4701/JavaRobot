package MacroFullVersion;

import java.awt.Point;

public class EventHandle {
	
	private String event_name;
	private Point position;
	private int key_number;
	
	public EventHandle(String event_name, Point position)
	{
		this.event_name = event_name;
		this.position = position;
	}
		
	public EventHandle(String event_name, int key_number)
	{
		this.event_name = event_name;
		this.key_number = key_number;
	}
	
	String getEventName()
	{
		return event_name;
	}

	Point getPosition()
	{
		return position;
	}
	
	int getPressKeyNumber()
	{
		return key_number;
	}
}

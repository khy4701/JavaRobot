package MacroFullVersion;


import java.util.ArrayList;

import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;

public class KeyboardListen implements NativeKeyListener {
	
	//
	private ArrayList<EventHandle> arrayList; 
	
	public KeyboardListen(ArrayList<EventHandle> arrayList)
	{
		this.arrayList = arrayList;
	}

	@Override
	public void nativeKeyPressed(NativeKeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void nativeKeyReleased(NativeKeyEvent e) {
		// TODO Auto-generated method stub
		
	} 

	@Override
	public void nativeKeyTyped(NativeKeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
